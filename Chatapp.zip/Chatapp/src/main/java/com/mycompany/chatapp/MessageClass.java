
package com.mycompany.chatapp;

import java.util.Scanner;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

public class MessageClass {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        
        public void storeMessage() {

    try {

        FileWriter writer =
                new FileWriter(
                        "storedMessages.json",
                        true);

        writer.write(
                "{\n" +
                "\"messageID\":\""
                + messageID + "\",\n" +

                "\"recipient\":\""
                + recipient + "\",\n" +

                "\"message\":\""
                + message + "\"\n" +

                "}\n"
        );

        writer.close();

    } catch (IOException e) {

        System.out.println(
                "Error storing message.");
    }
}

         private static int totalMessages = 0;

    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    
    public String getRecipient() {
    return recipient;
}

public String getMessage() {
    return message;
}

public String getMessageHash() {
    return messageHash;
}

public String getMessageID() {
    return messageID;
}

    // Constructor
    public Message(String recipient, String message){

        this.recipient = recipient;
        this.message = message;

        generateMessageID();

        totalMessages++;

        createMessageHash();
    }

    // Generate Message ID
    private void generateMessageID() {

        Random random = new Random();

        long number =
                1000000000L +
                (long)(random.nextDouble() * 8999999999L);

        messageID = String.valueOf(number);
    }

    // Check Message ID
    public boolean checkMessageID() {

        return messageID.length() <= 10;
    }

    // Check Recipient Cell
    public String checkRecipientCell() {

        if (recipient.matches("^\\+27\\d{9}$")) {

            return "Cell phone number successfully captured.";

        } else {

            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Validate Message Length
    public String validateMessageLength() {

        if (message.length() <= 250) {

            return "Message ready to send.";

        } else {

            int extra =
                    message.length() - 250;

            return "Message exceeds 250 characters by "
                    + extra
                    + "; please reduce the size.";
        }
    }

    // Create Message Hash
    public String createMessageHash() {

        String[] words = message.split(" ");

        String firstWord = words[0].toUpperCase();

        String lastWord =
                words[words.length - 1].toUpperCase();

        messageHash =
                messageID.substring(0, 2)
                + ":"
                + totalMessages
                + ":"
                + firstWord
                + lastWord;

        return messageHash;
    }

    // Send Message Option
    public String sentMessage(int option) {

        switch (option) {

            case 1:
                return "Message successfully sent.";

            case 2:
                return "Press 0 to delete the message.";

            case 3:
                return "Message successfully stored.";
                
                

            default:
                return "Invalid option.";
        }
    }

    // Print Messages
    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    // Total Messages
    public static int returnTotalMessages() {

        return totalMessages;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getMessageID() {
        return messageID;
        

        Loginlogin = new Login();

        System.out.println("===== QUICKCHAT LOGIN =====");

        login.registerUser(
                "kyl_1",
                "Password@1",
                "+27838968976"
        );

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        boolean status =
                login.loginUser(username, password);

        if (status) {

            System.out.println(
                    "Welcome to QuickChat."
            );

            System.out.print(
                    "How many messages would you like to enter? "
            );

            int numberMessages =
                    input.nextInt();

            input.nextLine();

            int choice = 0;

            while (choice != 3) {

                System.out.println("\n===== MENU =====");
                System.out.println("1. Send Messages");
                System.out.println("2. Show Recently Sent Messages");
                System.out.println("3. Quit");
                System.out.println("4. Stored Messages");

                System.out.print("Choose option: ");

                choice = input.nextInt();

                input.nextLine();

                switch (choice) {

                    case 1:

                        for (int i = 0; i < numberMessages; i++) {

                            System.out.print(
                                    "Enter recipient number: "
                            );

                            String recipient =
                                    input.nextLine();

                            System.out.print(
                                    "Enter message: "
                            );

                            String text =
                                    input.nextLine();

                            Message msg =
                                    new Message(recipient, text);

                            System.out.println(
                                    msg.checkRecipientCell()
                            );

                            System.out.println(
                                    msg.validateMessageLength()
                            );

                            System.out.println(
                                    "Choose:"
                            );

                            System.out.println(
                                    "1. Send"
                            );

                            System.out.println(
                                    "2. Disregard"
                            );

                            System.out.println(
                                    "3. Store"
                            );

                            int sendOption =
                                    input.nextInt();

                            input.nextLine();

                            System.out.println(
                                    msg.sentMessage(sendOption)
                            );

                            System.out.println(
                                    msg.printMessages()
                            );
                        }

                        System.out.println(
                                "Total messages sent: "
                                + Message.returnTotalMessages()
                        );

                        break;

                    case 2:

                        System.out.println(
                                "Coming Soon."
                        );

                        break;

                    case 3:

                        System.out.println(
                                "Goodbye!"
                        );

                        break;
                    
                    case 4:

    System.out.println(
            "\n===== STORED MESSAGES =====");

    System.out.println(
            "1. Display Stored Messages");

    System.out.println(
            "2. Longest Message");

    System.out.println(
            "3. Search Message ID");

    System.out.println(
            "4. Search Recipient");

    System.out.println(
            "5. Delete Message");

    System.out.println(
            "6. Display Report");

    int storedChoice =
            input.nextInt();

    input.nextLine();

    switch (storedChoice) {

        case 1:

            manager.displayStoredMessages();

            break;

        case 2:

            System.out.println(
                    manager.getLongestMessage());

            break;

        case 3:

            System.out.print(
                    "Enter Message ID: ");

            String id =
                    input.nextLine();

            System.out.println(
                    manager.searchMessageID(id));

            break;

        case 4:

            System.out.print(
                    "Enter Recipient: ");

            String recipient =
                    input.nextLine();

            System.out.println(
                    manager.searchRecipient(recipient));

            break;

        case 5:

            System.out.print(
                    "Enter Message Hash: ");

            String hash =
                    input.nextLine();

            System.out.println(
                    manager.deleteMessage(hash));

            break;

        case 6:

            manager.displayReport();

            break;
    }

    break;    

                    default:

                        System.out.println(
                                "Invalid option."
                        );
                }
            }

        } else {

            System.out.println(
                    "Username or password incorrect."
            );
            

            
                   
    

    

    


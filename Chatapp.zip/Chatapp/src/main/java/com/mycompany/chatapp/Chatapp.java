

package com.mycompany.chatapp;

import java.util.Scanner;

public class Chatapp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
         Login login = new Login();

        System.out.println("===== QUICKCHAT REGISTRATION =====");

        System.out.print("Enter First Name: ");
        String firstName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = input.nextLine();

        System.out.print("Enter Username: ");
        String username = input.nextLine();

        System.out.println(login.checkUserName(username));

        System.out.print("Enter Password: ");
        String password = input.nextLine();

        System.out.println(login.checkPasswordComplexity(password));

        System.out.print("Enter Cellphone Number: ");
        String cellPhone = input.nextLine();

        System.out.println(login.checkCellPhoneNumber(cellPhone));

        System.out.println(login.registerUser(username, password, cellPhone));

        System.out.println("\n===== LOGIN =====");

        System.out.print("Enter Username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter Password: ");
        String loginPassword = input.nextLine();

        boolean loginStatus = login.loginUser(loginUsername, loginPassword);

        System.out.println(
                login.returnLoginStatus(
                        loginStatus,
                        firstName,
                        lastName
                )
        );
        
    }
}


package com.mycompany.chatapp;


public class LoginClass {
      String storedUsername;
     String storedPassword;
     String storedCellPhone;

    // Username Validation
    public String checkUserName(String username) {

        if (username.contains("_") && username.length() <= 5) {
            return "Username successfully captured.";
        } else {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
    }

    // Password Validation
    public String checkPasswordComplexity(String password) {

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {

            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapital = true;
            }

            if (Character.isDigit(ch)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(ch)) {
                hasSpecial = true;
            }
        }

        if (password.length() >= 8 && hasCapital && hasNumber && hasSpecial) {

            return "Password successfully captured.";

        } else {

            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
    }

    // Cellphone Validation
    public String checkCellPhoneNumber(String cellPhone) {

        /*
         Regex Reference:
         Oracle Java Documentation:
         https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
         */

        if (cellPhone.matches("^\\+27\\d{9}$")) {

            return "Cell phone number successfully added.";

        } else {

            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
    }

    // Register User
    public String registerUser(String username, String password, String cellPhone) {

        boolean validUsername =
                username.contains("_") && username.length() <= 5;

        boolean validPassword =
                password.length() >= 8 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*\\d.*") &&
                password.matches(".*[^a-zA-Z0-9].*");

        boolean validCell =
                cellPhone.matches("^\\+27\\d{9}$");

        if (!validUsername) {

            return "Username is incorrectly formatted.";

        }

        if (!validPassword) {

            return "Password does not meet complexity requirements.";

        }

        if (!validCell) {

            return "Cell phone number incorrectly formatted.";
        }

        storedUsername = username;
        storedPassword = password;
        storedCellPhone = cellPhone;

        return "User has been registered successfully.";
    }

    // Login Verification
    public boolean loginUser(String username, String password) {

        return username.equals(storedUsername)
                && password.equals(storedPassword);
    }

    // Login Status Message
    public String returnLoginStatus(
            boolean loginStatus,
            String firstName,
            String lastName
    ) {

        if (loginStatus) {

            return "Welcome " + firstName + ", "
                    + lastName + " it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}

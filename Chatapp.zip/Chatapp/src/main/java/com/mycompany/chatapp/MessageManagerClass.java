
package com.mycompany.chatapp;

import java.util.ArrayList;


public class MessageManagerClass {
    
    private ArrayList<Message> sentMessages =
            new ArrayList<>();

    private ArrayList<Message> storedMessages =
            new ArrayList<>();

    private ArrayList<Message> disregardedMessages =
            new ArrayList<>();

    // Add message according to user choice
    public void addMessage(Message message, int option) {

        if (option == 1) {
            sentMessages.add(message);
        }

        else if (option == 2) {
            disregardedMessages.add(message);
        }

        else if (option == 3) {
            storedMessages.add(message);
        }
    }

    // Display sender and recipient
    public void displayStoredMessages() {

        for (Message message : storedMessages) {

            System.out.println(
                    "Recipient: "
                    + message.getRecipient());

            System.out.println(
                    "Message: "
                    + message.getMessage());

            System.out.println("----------------");
        }
    }

    // Longest message
    public String getLongestMessage() {

        String longest = "";

        for (Message message : storedMessages) {

            if (message.getMessage().length()
                    > longest.length()) {

                longest = message.getMessage();
            }
        }

        return longest;
    }

    // Search by Message ID
    public String searchMessageID(String id) {

        for (Message message : storedMessages) {

            if (message.getMessageID().equals(id)) {

                return "Recipient: "
                        + message.getRecipient()
                        + "\nMessage: "
                        + message.getMessage();
            }
        }

        return "Message not found.";
    }

    // Search by Recipient
    public String searchRecipient(String recipient) {

        String results = "";

        for (Message message : storedMessages) {

            if (message.getRecipient()
                    .equals(recipient)) {

                results += message.getMessage()
                        + "\n";
            }
        }

        return results;
    }

    // Delete by Hash
    public String deleteMessage(String hash) {

        for (int i = 0;
                i < storedMessages.size();
                i++) {

            if (storedMessages.get(i)
                    .getMessageHash()
                    .equals(hash)) {

                String deleted =
                        storedMessages.get(i)
                                .getMessage();

                storedMessages.remove(i);

                return "Message: \""
                        + deleted
                        + "\" successfully deleted.";
            }
        }

        return "Message hash not found.";
    }

    // Report
    public void displayReport() {

        System.out.println(
                "\n===== MESSAGE REPORT =====");

        for (Message message : sentMessages) {

            System.out.println(
                    "Message Hash: "
                    + message.getMessageHash());

            System.out.println(
                    "Recipient: "
                    + message.getRecipient());

            System.out.println(
                    "Message: "
                    + message.getMessage());

            System.out.println("------------------");
        }
    }
}
    


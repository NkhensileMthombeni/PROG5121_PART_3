
package com.mycompany.chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author 26823225
 */
public class MessageClassTest {
    
    public MessageClassTest() {
    }

    /**
     * Test of main method, of class MessageClass.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        MessageClass.main(args);
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkMessageID method, of class MessageClass.
     */
    @Test
    public void testCheckMessageID() {
        System.out.println("checkMessageID");
        MessageClass instance = null;
        boolean expResult = false;
        boolean result = instance.checkMessageID();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkRecipientCell method, of class MessageClass.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        MessageClass instance = null;
        String expResult = "";
        String result = instance.checkRecipientCell();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of validateMessageLength method, of class MessageClass.
     */
    @Test
    public void testValidateMessageLength() {
        System.out.println("validateMessageLength");
        MessageClass instance = null;
        String expResult = "";
        String result = instance.validateMessageLength();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of createMessageHash method, of class MessageClass.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        MessageClass instance = null;
        String expResult = "";
        String result = instance.createMessageHash();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of sentMessage method, of class MessageClass.
     */
    @Test
    public void testSentMessage() {
        System.out.println("sentMessage");
        int option = 0;
        MessageClass instance = null;
        String expResult = "";
        String result = instance.sentMessage(option);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of printMessages method, of class MessageClass.
     */
    @Test
    public void testPrintMessages() {
        System.out.println("printMessages");
        MessageClass instance = null;
        String expResult = "";
        String result = instance.printMessages();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnTotalMessages method, of class MessageClass.
     */
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        int expResult = 0;
        int result = MessageClass.returnTotalMessages();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageHash method, of class MessageClass.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        MessageClass instance = null;
        String expResult = "";
        String result = instance.getMessageHash();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMessageID method, of class MessageClass.
     */
    @Test
    public void testGetMessageID() {
        System.out.println("getMessageID");
        MessageClass instance = null;
        String expResult = "";
        String result = instance.getMessageID();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }
    
}


package com.mycompany.chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class LoginClassTest {
    
    public LoginClassTest() {
    }

    /**
     * Test of checkUserName method, of class LoginClass.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String username = "";
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.checkUserName(username);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class LoginClass.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "";
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkCellPhoneNumber method, of class LoginClass.
     */
    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String cellPhone = "";
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.checkCellPhoneNumber(cellPhone);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class LoginClass.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "";
        String password = "";
        String cellPhone = "";
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.registerUser(username, password, cellPhone);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class LoginClass.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "";
        String password = "";
        LoginClass instance = new LoginClass();
        boolean expResult = false;
        boolean result = instance.loginUser(username, password);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class LoginClass.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean loginStatus = false;
        String firstName = "";
        String lastName = "";
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.returnLoginStatus(loginStatus, firstName, lastName);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }
    
}

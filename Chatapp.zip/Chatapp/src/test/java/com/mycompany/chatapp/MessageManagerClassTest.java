
package com.mycompany.chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class MessageManagerClassTest {
    
    public MessageManagerClassTest() {
    }

    /**
     * Test of addMessage method, of class MessageManagerClass.
     */
    @Test
    public void testAddMessage() {
        System.out.println("addMessage");
        Object message = null;
        int option = 0;
        MessageManagerClass instance = new MessageManagerClass();
        instance.addMessage(message, option);
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayStoredMessages method, of class MessageManagerClass.
     */
    @Test
    public void testDisplayStoredMessages() {
        System.out.println("displayStoredMessages");
        MessageManagerClass instance = new MessageManagerClass();
        instance.displayStoredMessages();
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLongestMessage method, of class MessageManagerClass.
     */
    @Test
    public void testGetLongestMessage() {
        System.out.println("getLongestMessage");
        MessageManagerClass instance = new MessageManagerClass();
        String expResult = "";
        String result = instance.getLongestMessage();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchMessageID method, of class MessageManagerClass.
     */
    @Test
    public void testSearchMessageID() {
        System.out.println("searchMessageID");
        String id = "";
        MessageManagerClass instance = new MessageManagerClass();
        String expResult = "";
        String result = instance.searchMessageID(id);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchRecipient method, of class MessageManagerClass.
     */
    @Test
    public void testSearchRecipient() {
        System.out.println("searchRecipient");
        String recipient = "";
        MessageManagerClass instance = new MessageManagerClass();
        String expResult = "";
        String result = instance.searchRecipient(recipient);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteMessage method, of class MessageManagerClass.
     */
    @Test
    public void testDeleteMessage() {
        System.out.println("deleteMessage");
        String hash = "";
        MessageManagerClass instance = new MessageManagerClass();
        String expResult = "";
        String result = instance.deleteMessage(hash);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayReport method, of class MessageManagerClass.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        MessageManagerClass instance = new MessageManagerClass();
        instance.displayReport();
        fail("The test case is a prototype.");
    }
    
}
